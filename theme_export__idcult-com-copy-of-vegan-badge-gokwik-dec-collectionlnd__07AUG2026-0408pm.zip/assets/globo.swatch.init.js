var globoSwatchInit = true;
